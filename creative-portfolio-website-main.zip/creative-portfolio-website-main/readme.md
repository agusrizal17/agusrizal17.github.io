
========================================================================
<h1 style="align: center;"><a href="https://xsrazy.my.id" target="_blank">DEMO</a></h1>
<h3>Xsrazy is a modern and clean personal vCard website template. It has many cool features found
in premium templates. It has timeline items, stats section, skillbars, working ajax form,
frontend form validation, a portfolio section to showcase your works and many more. It looks 
great on all devices from mobile to desktop. It's also retina ready so your site will look 
crisp and sharp on any device. Kards is the ideal template for creating digital personal resume 
and portfolio website.
 </h3>

<a href="https://www.buymeacoffee.com/xsrazy" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

========================================================================
